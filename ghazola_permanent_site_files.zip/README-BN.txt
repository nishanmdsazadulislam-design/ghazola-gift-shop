Ghazola Gift Shop — স্থায়ী QR পেজ সেটআপ

১) ZIP ফাইলটি Extract করুন।
২) GitHub repository খুলুন:
   https://github.com/nishanmdsazadulislam-design/ghazola-gift-shop
৩) Add file > Upload files নির্বাচন করুন।
৪) index.html, README-BN.txt এবং images ফোল্ডারের সব ফাইল আপলোড করে Commit changes করুন।
৫) Repository > Settings > Pages এ যান।
৬) Build and deployment: Deploy from a branch নির্বাচন করুন।
৭) Branch: main এবং folder: /(root) নির্বাচন করে Save করুন।
৮) কয়েক মিনিট পরে সাইটটি এখানে প্রকাশিত হবে:
   https://nishanmdsazadulislam-design.github.io/ghazola-gift-shop/

গুরুত্বপূর্ণ: ghazola_permanent_site_qr.png-এ থাকা QR কোডটি উপরের সাইটের ঠিকানায় যায়।
সাইটটি প্রকাশিত হওয়ার আগে QR কোডটি খুলবে না। এই QR কোডটি Samsung Quick Share-এর মেয়াদোত্তীর্ণ লিংকের ওপর নির্ভর করে না।
